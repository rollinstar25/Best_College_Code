# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 20:40:48 2017
Project 3 SnapChat Filters Upgraded

@author: Grace Street and Sierra Sarver
SSARVER@rollins.edu
MSTREET@rollins.edu

On our honor we have not given nor received nor witnessed any unauthorized 
assistance on this work.

Collaboration Statement: We worked alone on this project using only authorized 
class materials and online resources.
Online Resources:
    video capture-> https://docs.opencv.org/3.0-beta/doc/py_tutorials/py_gui/
                     py_video_display/py_video_display.html#display-video
                 -> https://realpython.com/blog/python/
                    `aface-detection-in-python-using-a-webcam/
                ->  https://www.youtube.com/watch?v=88HdqNDQsEk&t=586s
    
"""
import cv2
import numpy as np


"""
We want to apply various snapchat selfie filters using live video feeds.
"""

#Im not sure how we want to do these methods yet
def dog_face_filter(dog_pic, video, x, y, width, height):
    """
    This method applies the dog face filter onto the video.
    
    Args:
        dog_pic -> picture of dog face
        video -> video we are applying to filter to
        x -> x posistion on video
        y -> y posistion on video
        width -> width of video
        height -> height of video
        
    Returns:
        dog_face_video -> filtered video
    """
    
def heart_eyes_filter(heart_pic, video, x, y, width, height):
    """
    This method applies the heart eyes filter onto the video.
    
    Args:
        heart_pic -> picture of heart eyes
        video -> video we are applying to filter to
        x -> x posistion on video
        y -> y posistion on video
        width -> width of video
        height -> height of video
        
    Returns:
        heart_eyes_video -> filtered video
    """
    
def buck_teeth_filter(buck_teeth_pic, video, x, y, width, height):
    """
    This method applies the dog face filter onto the video.
    
    Args:
        buck_teeth_pic -> picture of buck teeth
        video -> video we are applying to filter to
        x -> x posistion on video
        y -> y posistion on video
        width -> width of video
        height -> height of video
        
    Returns:
        buck_teeth_video -> filtered video
    """
    
def face_swap(face_swap_pic, video, x, y, width, height):
    """
    This method applies the dog face filter onto the video.
    
    Args:
        face_swap_pic -> picture of face swapping
        video -> video we are applying to filter to
        x -> x posistion on video
        y -> y posistion on video
        width -> width of video
        height -> height of video
        
    Returns:
        face_swap_video -> filtered video
    """
"""
This captures the video
"""
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
#smile_cascade = cv2.CascadeClassifier('haarcascade_smile.xml')
capture = cv2.VideoCapture(0)
while True :
    # Capture frame-by-frame
    ret, frame = capture.read()
    
    # Our operations on the frame come here
    #The reason we convert to gray first is because it's better for the detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    #Draw a rectangle around the faces(Green)
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        roi_gray = gray[y:y+h, x:x+h]
        roi_color = frame[y:y+h, x:x+h]
        eyes = eye_cascade.detectMultiScale(roi_gray, 1.3, 2)
        #Draws the rectangle around the eyes(Blue)
        for (ex, ey, ew, eh) in eyes:
            cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (255, 0, 0), 2)
        #For the following rectangles, I had to guesstimate where those features are on the average person
        #Be careful messing with these, parentheses and stuff like that...
        #Draws the rectangle for the nose at the center of the rectangle for face (Teal)
        cv2.rectangle(frame, (int((x+(w/2))-(ew/2.5)), int((y+(h/2))-(eh/2.5))), (int((x+(w/2))+(ew/2.5)), int((y+(h/2))+(eh/2.5))), (255, 255, 0), 2)
        #Draws the rectangle for the mouth at about 2/3 of the way down the face rectangle (Purple)
        cv2.rectangle(frame, (int(x+(w/3)), int(y+((2/3)*h))), (int((x+((2/3)*w))), int((y+((2/3)*h))+eh)),(255, 0, 255), 2)
        """
            #The smile cascade makes it really sensitive, if I squint my eyes, 
            #it reads as a smile. 
        smiles = smile_cascade.detectMultiScale(roi_gray, 1.3, 1)
        for (sx, sy, sw, sh) in smiles:
            cv2.rectangle(roi_color, (ex, ey), (int(1.5*(ex+ew)), ey+eh), (0, 0, 255), 2)
        """
    # Display the resulting frame
    cv2.imshow('frame', frame)
    #Press the 'q' key to close the video feed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
        # When everything done, release the capture
capture.release()
cv2.destroyAllWindows()
    
